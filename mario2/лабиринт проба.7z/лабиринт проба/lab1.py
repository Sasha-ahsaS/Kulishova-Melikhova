import pygame
import random

PINK = (221, 160, 221)
WHITE = (255, 255, 255)
BLUE = (29, 32, 76)

SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
FPS = 30


class Player(pygame.sprite.Sprite):

    def __init__(self, x, y, img='p (1).png'):
        super().__init__()

        self.image = pygame.image.load(img).convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

        self.change_x = 0
        self.change_y = 0
        self.walls = None

        # Добавляем пятно
        self.coins = None
        self.collection_coins = 0

        # Добавляем врага
        self.enemies = pygame.sprite.Group()
        # Игрок жив пока не встретит противника
        self.alive = True

    def update(self):
        #  Движение вправо - влево
        self.rect.x += self.change_x
        # Проверим, что объект не врезается в стену
        block_hit_list = pygame.sprite.spritecollide(self, self.walls, False)
        for block in block_hit_list:
            # Если игрок двигается в право, вернем его правую границу к левой границе препятствия
            if self.change_x > 0:
                self.rect.right = block.rect.left
            # Если в лево все наоборот
            else:
                self.rect.left = block.rect.right
        #  Движение вверх - вниз
        self.rect.y += self.change_y
        # Проверим, что объект не врезается в стену
        block_hit_list = pygame.sprite.spritecollide(self, self.walls, False)
        for block in block_hit_list:
            # Вернем игрока за грнацу препятствия
            if self.change_y > 0:
                self.rect.botton = block.rect.top
            else:
                self.rect.top = block.rect.botton

        # Проверим, что игрок встретил пятно
        coins_hit_list = pygame.sprite.spritecollide(self, self.coin, False)
        for coin in coins_hit_list:
            self.collection_coins += 1
            coin.kill()
        # Проверим, что игрок встретил  противника
        if pygame.sprite.spritecollide(self, self.enemies, False):
            self.alive = False


class Wall(pygame.sprite.Sprite):
    def __init__(self, x, y, width, height):
        super().__init__()

        self.image = pygame.Surface([width, height])
        self.image.fill(BLUE)
        self.rect = self.image.get_rect()
        self.rect.y = y
        self.rect.x = x


# Класс клякс которые нужно собрать
class Coin(pygame.sprite.Sprite):
    def __init__(self, x, y, img='клякса.jpg'):
        super().__init__()
        self.image = pygame.image.load(img).convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y


# Класс для врага
class Enemy(pygame.sprite.Sprite):
    def __init__(self, x, y, img='босс.png'):
        super().__init__()
        self.image = pygame.image.load(img).convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        #
        self.start = x
        self.stop = x + random.randint(180, 240)
        self.direction = 1

    def update(self):
        # спрайт дошел, то стоп и должен повернуть обратно налево
        if self.rect.x >= self.stop:
            self.rect.x = self.stop
            self.direction = -1
        # спрайт дошел, то старт и должен повернуть обратно направо
        if self.rect.x <= self.start:
            self.rect.x = self.start
            self.direction = 1
        # смещать спрайт в указанном направление
        self.rect.x += self.direction * 2


pygame.init()
screen = pygame.display.set_mode([SCREEN_WIDTH, SCREEN_HEIGHT])
pygame.display.set_caption('Тимошка')

all_sprite_list = pygame.sprite.Group()
wall_list = pygame.sprite.Group()
coin_list = pygame.sprite.Group()

wall_coord = [[0, 0, 10, 600], [790, 0, 10, 600], [10, 0, 790, 10],
               [0, 200, 100, 10], [0, 590, 600, 10], [450, 400, 10, 200], [550, 450, 250, 10]]
for coord in wall_coord:
    wall = Wall(coord[0], coord[1], coord[2], coord[3])
    wall_list.add(wall)
    all_sprite_list.add(wall)

coin_coord = [[150, 200], [120, 80]]
for coord in coin_coord:
    coin = Coin(coord[0], coord[1])
    coin_list.add(coin)
    all_sprite_list.add(coin)

# Создаем противника
enemies_list = pygame.sprite.Group()
enemies_coord = [[10, 500], [400, 50]]
for coord in enemies_coord:
    enemy = Enemy(coord[0], coord[1])
    enemies_list.add(enemy)
    all_sprite_list.add(enemy)

player = Player(150, 150)
player.walls = wall_list
player.coin = coin_list
all_sprite_list.add(player)
player.enemies = enemies_list

font = pygame.font.SysFont('Arial', 24, True)
text = font.render('Игра окончена', True, WHITE)
text_vin = font.render('', True, WHITE)

clock = pygame.time.Clock()
done = False

while not done:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True
        elif event.type == pygame.KEYDOWN:
            player.change_x = -5
        elif event.type == pygame.K_LEFT:
            player.change_x = 5
        elif event.type == pygame.K_RIGHT:
            player.change_y = -5
        elif event.type == pygame.K_DOWN:
            player.change_y = 5
        elif event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT:
                player.change_x = 0
            elif event.key == pygame.K_RIGHT:
                player.change_x = 0
            elif event.key == pygame.K_UP:
                player.change_y = 0
            elif event.key == pygame.K_DOWN:
                player.change_y = 0

    screen.fill(PINK)
    if not player.alive:
        screen.blit(text, (100, 100))
    else:
        all_sprite_list.update()
        all_sprite_list.draw(screen)

    pygame.display.flip()
    clock.tick(60)
pygame.quit()